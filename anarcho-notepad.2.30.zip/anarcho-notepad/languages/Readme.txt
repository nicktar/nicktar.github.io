
CONTRIBUTING YOUR TRANSLATION


"Anarcho-Notepad" theme is ready for translation. It written on English and translated into:
  * Russian (translated by Arthur Gareginyan)
  * Ukrainian (translated by Svetlana Drotyanko)
  * Slovak (translated by Martin Petrus)
  * Afrikaans (translated by MadriVictor)
  * Spanish (translated by Ivan Ratinoff)
  * Polish (translated by Krzysztof Goral)
  * German (translated by Alexander v. Falkenhausen)
  * Estonian (translated by Taavi Tiitsmaa)
  * Catalan (translated by Nestor Malet)
  * Danish (translated by Chano Klinck Andersen)
  * French (translated by Rolland Dudemaine)

If you want to help translate this theme, please use the POT file, that is included and placed in the "languages" folder, in order to create a translation files (*.po, *.mo). Just send the translation files (*.po, *.mo) to me at arthurgareginyan@gmail.com and I will include the translation within the next theme update.

Also you can use an existing PO file that placed in the "languages" folder, in order to make corrections.

Many of plugin users would be delighted if you share your translation with the community. Thanks for your contribution!

Thanks for your contribution!